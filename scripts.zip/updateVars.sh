# Use ./

tenantProfile=six
deploymentAccount=999999999
bucketName=mad-matrixtech2
tenantAccountID=888888888
region=us-east-1

cd modified/

sed -i "s/<TOOLING_ACCOUNT_ID>/$deploymentAccount/g" *.sh
sed -i "s/<TENANT_PROFILE_NAME>/$tenantProfile/g" *.sh
sed -i "s/<TENANT_ACCOUNT_ID>/$tenantAccountID/g" *.sh
sed -i "s/<BUCKET_UNIQUE_NAME>/$bucketName/g" *.sh
sed -i "s/<YOUR_REGION>/$region/g" *.sh

./2.sh
./3.sh
./4.sh
./5.sh
./6.sh
./7.sh
./8.sh
./9.sh

		


